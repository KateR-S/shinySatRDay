library(shiny)
library(miniUI)

satRdayGadget <- function() {

# add your gadget functionality in here!
}
